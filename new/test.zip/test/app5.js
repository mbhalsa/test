


const express = require("express");
const exphbs = require("express-handlebars");

const app = express();

// setup handlebars
app.engine("handlebars", exphbs.engine());
app.set("view engine", "handlebars");

// route
app.get("/", (req, res) => {
  const userInput = req.query.name;
  
  res.render("home4", {
    name: userInput
  });
});

// server
app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});