const express = require("express");
const exphbs = require("express-handlebars");

const app = express();

app.use(express.urlencoded({ extended: true }));

// handlebars
app.engine("handlebars", exphbs.engine());
app.set("view engine", "handlebars");


app.get("/", (req, res) => {
    res.render("home5", {
        token: "123ABC" // CSRF simple (simulation)
    });
});


app.post("/submit", (req, res) => {
    console.log("Username:", req.body.username);
    console.log("Token:", req.body.csrfToken);

    res.send("Form submitted successfully");
});

// serveur
app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});