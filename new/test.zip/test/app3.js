const express = require("express");
const exphbs = require("express-handlebars");

const app = express();

// setup handlebars
app.engine("handlebars", exphbs.engine());
app.set("view engine", "handlebars");

// route
app.get("/", (req, res) => {
  res.render("home2", {
       users: [
        { name: "Ali", age: 20 },
        { name: "Sara", age: 21 }
    ]

  });
});

// server
app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});