# Task Tracker

## Run the project

```bash
npm install
npm run dev
```

Open: http://localhost:3000

## Features

- View all tasks
- Add a new task
- Data stored in `repo/data/tasks.json`
