import { readFile, writeFile } from "fs/promises"
import path from "path"

const filePath = path.join(process.cwd(), "repo", "data", "tasks.json")

export async function getAllTasks() {
    const data = await readFile(filePath, "utf-8")
    return JSON.parse(data)
}

export async function saveAllTasks(tasks) {
    await writeFile(filePath, JSON.stringify(tasks, null, 4))
}

export async function addTask(title) {
    const tasks = await getAllTasks()

    const newTask = {
        id: Date.now().toString(),
        title: title,
        completed: false
    }

    tasks.push(newTask)
    await saveAllTasks(tasks)

    return newTask
}
