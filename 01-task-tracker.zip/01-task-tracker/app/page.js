"use client"

const { useEffect, useState } = require("react")

function HomePage() {
    const [tasks, setTasks] = useState([])
    const [title, setTitle] = useState("")
    const [message, setMessage] = useState("")

    /**
     * Load all tasks from the API.
     */
    async function loadTasks() {
        try {
            const response = await fetch("/api/tasks")
            const data = await response.json()
            setTasks(data)
        }
        catch (error) {
            setMessage("Failed to load tasks.")
        }
    }

    /**
     * Add a new task using the API.
     * @param {Event} event
     */
    async function handleSubmit(event) {
        event.preventDefault()

        if (title.trim() === "") {
            setMessage("Please enter a task title.")
            return
        }

        try {
            const response = await fetch("/api/tasks", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    title: title
                })
            })

            const data = await response.json()

            if (!response.ok) {
                setMessage(data.error || "Failed to add task.")
                return
            }

            setTitle("")
            setMessage("Task added successfully.")
            loadTasks()
        }
        catch (error) {
            setMessage("Server error.")
        }
    }

    useEffect(function () {
        loadTasks()
    }, [])

    return (
        <main style={{ padding: "30px", fontFamily: "Arial" }}>
            <h1>Task Tracker</h1>

            <form onSubmit={handleSubmit} style={{ marginBottom: "20px" }}>
                <input
                    type="text"
                    placeholder="Enter task title"
                    value={title}
                    onChange={function (event) {
                        setTitle(event.target.value)
                    }}
                    style={{
                        padding: "10px",
                        width: "250px",
                        marginRight: "10px"
                    }}
                />

                <button type="submit" style={{ padding: "10px 16px" }}>
                    Add Task
                </button>
            </form>

            {message !== "" && <p>{message}</p>}

            <h2>Tasks</h2>

            {tasks.length === 0 ? (
                <p>No tasks yet.</p>
            ) : (
                <ul>
                    {tasks.map(function (task) {
                        return (
                            <li key={task.id}>
                                {task.title} - {task.completed ? "Completed" : "Not completed"}
                            </li>
                        )
                    })}
                </ul>
            )}
        </main>
    )
}

module.exports = HomePage
