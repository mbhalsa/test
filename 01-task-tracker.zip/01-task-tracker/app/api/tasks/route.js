const { getAllTasks, addTask } = require("../../../repo/tasks")

/**
 * Handle GET /api/tasks
 * @returns {Promise<Response>}
 */
async function GET() {
    try {
        const tasks = await getAllTasks()
        return Response.json(tasks, { status: 200 })
    }
    catch (error) {
        return Response.json(
            { error: "Failed to load tasks" },
            { status: 500 }
        )
    }
}

/**
 * Handle POST /api/tasks
 * @param {Request} request
 * @returns {Promise<Response>}
 */
async function POST(request) {
    try {
        const body = await request.json()

        if (!body.title || body.title.trim() === "") {
            return Response.json(
                { error: "Title is required" },
                { status: 400 }
            )
        }

        const newTask = await addTask(body.title.trim())

        return Response.json(newTask, { status: 201 })
    }
    catch (error) {
        return Response.json(
            { error: "Failed to create task" },
            { status: 500 }
        )
    }
}

module.exports = {
    GET,
    POST
}
