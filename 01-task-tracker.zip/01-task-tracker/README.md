# 01-task-tracker

A simple Next.js mini application for learning REST APIs.

## Features
- View all tasks
- Add a new task
- Store tasks in a JSON file

## Run the project

1. Open a terminal in the project folder
2. Install dependencies:

```bash
npm install
```

3. Start the development server:

```bash
npm run dev
```

4. Open in browser:

```text
http://localhost:3000
```

## API

### GET all tasks
`GET /api/tasks`

### Add a task
`POST /api/tasks`

Example JSON body:

```json
{
  "title": "Learn REST API"
}
```
