const fs = require("fs/promises")
const path = require("path")

const filePath = path.join(process.cwd(), "repo", "data", "tasks.json")

/**
 * Read all tasks from the JSON file.
 * @returns {Promise<Array>}
 */
async function getAllTasks() {
    const data = await fs.readFile(filePath, "utf-8")
    return JSON.parse(data)
}

/**
 * Save all tasks to the JSON file.
 * @param {Array} tasks
 * @returns {Promise<void>}
 */
async function saveAllTasks(tasks) {
    await fs.writeFile(filePath, JSON.stringify(tasks, null, 4))
}

/**
 * Add a new task to the JSON file.
 * @param {string} title
 * @returns {Promise<Object>}
 */
async function addTask(title) {
    const tasks = await getAllTasks()

    const newTask = {
        id: Date.now().toString(),
        title: title,
        completed: false
    }

    tasks.push(newTask)
    await saveAllTasks(tasks)

    return newTask
}

module.exports = {
    getAllTasks,
    addTask
}
